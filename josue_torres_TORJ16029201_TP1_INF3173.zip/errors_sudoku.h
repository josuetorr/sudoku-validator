#ifndef __ERRORS_SUDOKU__
#define __ERRORS_SUDOKU__

#define ERROR_ARG_MISSING 1
#define ERROR_FILE 2

#endif
