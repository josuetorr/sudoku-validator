-----------------------------------------------------------------------------
| Auteur: Josue Torres
| Courriel: josue.dtorres@gmail.com
| Code Permanent: TORJ16029201
| Version: 26 oct 2019
| Professeur: Ammar Hammad
| Objectif: Valider un ou plusieurs sudoku(s) en utilisant plusieurs threads
-----------------------------------------------------------------------------

Ce programme n'est pas complété. Il manque la validation des doublons dans une rangée, colomne et 3x3.

COMPILATION:
-----------
Pour compiler le programme, simplement taper `make` dans le terminal
Vous pouvez nettoyer l'exécutable avec la commande `make clean`

EXÉCUTION:
---------
Pour exécuter le programme, taper le nom de l'exécutable et passez en parametre le nom du fichier à ouvrir.
`$ ./sudoku.out tests.txt`

